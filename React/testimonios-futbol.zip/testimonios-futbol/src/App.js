import './App.css';
import Testimonio from './componentes/Testimonio.js';

function App() {
  return (
    <div className="App">
      <div className='contenedor-principal'>
        <h1>Maximos goleadores en su respectiva selección</h1>
        <Testimonio
          nombre='Javier Hernández Balcázar'
          pais='México'
          imagen='javier'
          posicion='Centro Delantero'
          equipo='Los Angeles Galaxy'
          testimonio='Es el máximo goleador histórico de la selección mexicana con 52 goles.​A nivel de clubes, su mejor actuación se dio con el Manchester United en la temporada 2010/2011 en donde fue campeón de la Premier League y la Community Shield, siendo uno de los goleadores del equipo y superando a grandes figuras como Wayne Rooney y Michael Owen.' />
        
        <Testimonio
          nombre='Cristiano Ronaldo'
          pais='Portugal'
          imagen='cristiano'
          posicion='Centro Delantero o Extremo Izquierdo'
          equipo='Al-Nassr Football Club'
          testimonio='Considerado con frecuencia el mejor y más completo futbolista, así como el mayor goleador del mundo, además de uno de los mejores de todos los tiempos;​ es uno de los futbolistas más laureados de la historia, habiendo ganado, entre otras distinciones, cinco veces el Balón de Oro, cinco premios de la FIFA al mejor jugador del mundo y cuatro Botas de Oro' />

<Testimonio
          nombre='Lionel Messi'
          pais='Argentina'
          imagen='leo'
          posicion='Centro Delantero o Centrocampista'
          equipo='Paris Saint-Germain Football Club'
          testimonio='Considerado con frecuencia el mejor jugador del mundo y uno de los mejores de todos los tiempos, es el único futbolista en la historia que ha ganado, entre otras distinciones, siete veces el Balón de Oro, siete premios de la FIFA al mejor jugador del mundo, seis Botas de Oro y dos Balones de Oro de la Copa Mundial de Fútbol. En 2020, se convirtió en el primer futbolista y el primer argentino en recibir un Premio Laureus y fue incluido en el Dream Team del Balón de Oro.' />  

<Testimonio
          nombre='Neymar da Silva Santos Júnior'
          pais='Brasil'
          imagen='neymar'
          posicion='Centro Delantero o Centrocampista'
          equipo='Paris Saint-Germain Football Club'
          testimonio='Considerado uno de los juveniles más prometedores del mundo,​ ganó tres Campeonatos Paulistas seguidos, una Copa de Brasil, y una Copa Libertadores, donde fue máximo goleador y mejor jugador del certamen, la primera del club desde 1963 con Pelé. En Brasil, empezó a hacerse conocido por sus regates llamativos, por haber ganado el Premio Puskás en 2011, y el Futbolista del Año en Sudamérica en 2011​ y 2012.​ En 2013, fue transferido al F.C Barcelona.' />  
      </div>      
    </div>
  );
}

export default App;
